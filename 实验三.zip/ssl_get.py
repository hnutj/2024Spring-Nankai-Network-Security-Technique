import requests
import certifi

url = "https://localhost"

try:
    response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, verify="/home/justina/ssl/rootCA.pem")
    
    # 检查响应状态码
    if response.status_code == 200:
        print("请求成功!")
        print("响应内容:", response.text)
    else:
        print(f"请求失败，状态码: {response.status_code}")
except requests.exceptions.RequestException as e:
    # 输出异常信息
    print(f"请求发生异常: {e}")

